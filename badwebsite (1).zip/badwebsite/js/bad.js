// /**
//  * Author: Christian Tidwell, Fay Mensah, Nicole Safty, Anna Woldstad 
//  * Created:  March, 2020
//  * 
//  * (c) Copyright by Christian Tidwell, Fay Mensah, Nicole Safty, Anna Woldstad  from CST 252: Scripting for Multimedia 
//  **/

function sortingArtist(name) {
  var len = name.length;
  var mod = len % 10;
  if (mod == 0) {
  return "KISS";
  } 
  else if (mod == 1) {
  return ("Black Sabbath"); 
  } 
  else if (mod == 2) {
  return "Van Halen"; 
  } 
  else if (mod == 3) {
  return "Metallica";  
  }
  else if (mod == 4) {
  return "Journey";  
  }
  else if (mod == 5) {
  return "The Runaways";  
  }
  else if (mod == 6) {
  return "Motorhead";  
  }
  else if (mod == 7) {
  return "Bad Company";  
  }
  else if (mod == 8) {
  return "Led Zepplin";
  }
  else if (mod == 9) {
  return "Motley Crue"; 
  }
  else if (mod == 10) {
  return "The Doors";
  }
  return band;
}

// All functions sends the output information to the div in the web browser
var myButton = document.getElementById("button");
myButton.addEventListener("click", function() {
  var name = document.getElementById("input").value;
  var band = sortingArtist(name);
  console.log(name, band);
  newText = "<p>The information said that you are " + band + "</p>";
  document.getElementById("output").innerHTML = band;
})